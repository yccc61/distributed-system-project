package kvserver

import (
	"encoding/gob"
	"fmt"
	"strings"
	"time"

	"github.com/cmu440/actor"
	"github.com/cmu440/kvcommon"
)

// Implement your queryActor in this file.
// See example/counter_actor.go for an example actor using the
// github.com/cmu440/actor package.

// TODO (3A, 3B): define your message types as structs
type Content struct {
	Value     string
	TimeStamp time.Time
}
type MGet struct {
	Sender *actor.ActorRef
	Key    string
}

type MPut struct {
	Sender *actor.ActorRef
	Key    string
	Value  string
}

type MList struct {
	Sender *actor.ActorRef
	Prefix string
}

type MIntro struct {
	Sender *actor.ActorRef
	Port   int
}

// recurring sync message
type MSync struct{}

type MUpdate struct {
	PutList map[string]*Content
}

type MRIntro struct {
	Sender *actor.ActorRef
}

type MRSync struct{}

type MRUpdate struct {
	PutList map[string]*Content
}

func init() {
	// TODO (3A, 3B): Register message types, e.g.:
	gob.Register(MGet{})
	gob.Register(MPut{})
	gob.Register(MList{})
	gob.Register(MIntro{})
	gob.Register(MSync{})
	gob.Register(MUpdate{})
	gob.Register(MRIntro{})
	gob.Register(MRSync{})
	gob.Register(MRUpdate{})
	gob.Register(kvcommon.GetReply{})
	gob.Register(kvcommon.ListReply{})
	gob.Register(kvcommon.PutReply{})
}

type queryActor struct {
	context *actor.ActorContext
	// TODO (3A, 3B): implement this!
	storage         map[string]*Content
	actorMap        map[int]*actor.ActorRef // store all the active actors, port --> actRefs
	putList         map[string]*Content     // local put on each round
	remotePutList   map[string]*Content
	isRemote        bool
	remoteActorList []*actor.ActorRef
}

// "Constructor" for queryActors, used in ActorSystem.StartActor.
// tellafter -->
func newQueryActor(context *actor.ActorContext) actor.Actor {
	return &queryActor{
		context: context,
		// TODO (3A, 3B): implement this!
		storage:         make(map[string]*Content),
		actorMap:        make(map[int]*actor.ActorRef),
		putList:         make(map[string]*Content),
		isRemote:        false,
		remoteActorList: nil,
		remotePutList:   make(map[string]*Content),
	}
}

// OnMessage implements actor.Actor.OnMessage.
func (actor *queryActor) OnMessage(message any) error {
	// TODO (3A, 3B): implement this!
	switch m := message.(type) {
	case MGet:
		content, ok := actor.storage[m.Key]
		value := ""
		if ok {
			value = content.Value
		}
		result := kvcommon.GetReply{
			Value: value,
			Ok:    ok,
		}
		actor.context.Tell(m.Sender, result)
	case MPut:
		// fmt.Println("MPUTTTT")
		time := time.Now()
		actor.storage[m.Key] = &Content{Value: m.Value, TimeStamp: time}
		result := kvcommon.PutReply{}
		actor.context.Tell(m.Sender, result)
		actor.putList[m.Key] = &Content{Value: m.Value, TimeStamp: time}
		// fmt.Println("PutList Update with", m.Key, m.Value)
		actor.remotePutList[m.Key] = &Content{Value: m.Value, TimeStamp: time}
		// fmt.Println("Remote PutList Update with", m.Key, m.Value, len(actor.remotePutList))
		// for port, actorRef := range actor.actorMap {
		// 	fmt.Println("testttt", port)
		// 	syncMsg := MSync{
		// 		Sender: actor.context.Self,
		// 		KVMap:  actor.storage}
		// 	actor.context.Tell(actorRef, syncMsg)
		// }

	case MList:
		entries := make(map[string]string)
		for key, content := range actor.storage {
			value := content.Value
			if strings.HasPrefix(key, m.Prefix) {
				entries[key] = value
			}
		}
		result := kvcommon.ListReply{
			Entries: entries,
		}
		actor.context.Tell(m.Sender, result)
	case MIntro:
		senderRef, senderPort := m.Sender, m.Port
		actor.actorMap[senderPort] = senderRef
		syncMsg := &MSync{}
		// fmt.Println("Send Sync to Self")
		actor.context.Tell(actor.context.Self, syncMsg)
	// 250
	// 800
	case MSync:
		// fmt.Println("Receive Syncc from self")
		updateMsg := &MUpdate{PutList: actor.putList}
		if len(updateMsg.PutList) > 0 {
			for _, ref := range actor.actorMap {
				// fmt.Println("Compare: ", actor.context.Self.Counter, ref.Counter)
				actor.context.Tell(ref, updateMsg)
				// if actor.context.Self.Counter != ref.Counter {
				// 	// fmt.Println("Send Update to", ref.Counter)

				// }
			}
		}
		// range of local actors with the put
		// third type of msg
		// empty the local put
		actor.putList = make(map[string]*Content)
		syncMsg := &MSync{}
		actor.context.TellAfter(actor.context.Self, syncMsg, time.Duration(300)*time.Millisecond)
		// for port, ref := range st
		// fmt.Println("Send SYnccccccc to ", senderPort)
	case MUpdate:
		// fmt.Println("Updated!")
		updatedList := m.PutList
		for key, content := range updatedList {
			con, exist := actor.storage[key]
			if !exist {
				actor.storage[key] = content
				actor.remotePutList[key] = content
			} else if con.TimeStamp.Before(content.TimeStamp) {
				actor.storage[key] = content
				actor.remotePutList[key] = content
			}
		}
	case MRIntro:
		// fmt.Println("Received Remote Intro", actor.context.Self)
		actor.remoteActorList = append(actor.remoteActorList, m.Sender)
		actor.isRemote = true
		syncMsg := &MRSync{}
		actor.context.Tell(actor.context.Self, syncMsg)

	case MRSync:
		// fmt.Println("Received Remote Sync")
		if !actor.isRemote {
			fmt.Println("Wait?")
			return fmt.Errorf("unexpected Remote Sync")
		}
		updateMsg := &MRUpdate{PutList: actor.remotePutList}
		if len(updateMsg.PutList) > 0 {
			// fmt.Println("Send Update with", len(actor.remoteActorList))
			for _, ref := range actor.remoteActorList {
				// fmt.Println("Compare: ", actor.context.Self.Counter, ref.Counter)
				actor.context.Tell(ref, updateMsg)
			}
		}
		actor.remotePutList = make(map[string]*Content)
		syncMsg := &MRSync{}
		actor.context.TellAfter(actor.context.Self, syncMsg, time.Duration(1200)*time.Millisecond)
	case MRUpdate:
		// fmt.Println("Received Remote Update", actor.context.Self)
		if !actor.isRemote {
			fmt.Println("What?")
			return fmt.Errorf("unexpected Remote Sync")
		}
		updatedList := m.PutList
		// fmt.Println("Receive Update List", len(updatedList))
		for key, content := range updatedList {
			// fmt.Println("MRUpdate Check: ", key, content.Value)
			con, exist := actor.storage[key]
			if !exist {
				actor.storage[key] = content
				actor.putList[key] = content
			} else if con.TimeStamp.Before(content.TimeStamp) {
				actor.storage[key] = content
				actor.putList[key] = content
			}
		}

	default:
		return fmt.Errorf("Unexpected counterActor message type: %T", m)
	}
	return nil
}
